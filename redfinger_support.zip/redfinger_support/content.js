chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'setFullScreen') {

        try {
            actionFullScreenRedfinger();
            sendResponse({ status: 'success' });
        } catch {
            sendResponse({ status: 'error' });
        }
        

    } else if (request.action === 'setFullScreenFullSite') {
        try {
            fullScreenFullSite();
            sendResponse({ status: 'success' });
        } catch {
            sendResponse({ status: 'error' });
        }
      
    } else if(request.action == 'getLocalStorage') {
        try {
            var localStorage = getLocalStorage();
            if (localStorage == false) {
                sendResponse({ status: 'error' });
                return;
            }
            sendResponse({ status: 'success', data: localStorage });
        } catch {
            sendResponse({ status: 'error' });
        }
    }
  });



function getLocalStorage () {
    try {
        return JSON.stringify(localStorage);
    } catch {
        return false;
    }
    
}

function actionFullScreenRedfinger () {
    if (checkFullScreenRedfinger()) {
        exitFullScreenRedfinger();
    }
    else {
        fullScreenRedfinger();
    }

}

function fullScreenRedfinger () {
    var deviceScreen = document.querySelector("#redfinger-phone");
    if (deviceScreen.requestFullscreen) {
          deviceScreen.requestFullscreen();
    } else if (deviceScreen.mozRequestFullScreen) { // Firefox
          deviceScreen.mozRequestFullScreen();
    } else if (deviceScreen.webkitRequestFullscreen) { // Chrome, Safari and Opera
          deviceScreen.webkitRequestFullscreen();
    } else if (deviceScreen.msRequestFullscreen) { // IE/Edge
          deviceScreen.msRequestFullscreen();
    }
}


function fullScreenFullSite () {
    if (document.documentElement.requestFullscreen) {
        document.documentElement.requestFullscreen();
    } else if (document.documentElement.mozRequestFullScreen) { // Firefox
        document.documentElement.mozRequestFullScreen();
    } else if (document.documentElement.webkitRequestFullscreen) { // Chrome, Safari and Opera
        document.documentElement.webkitRequestFullscreen();
    } else if (document.documentElement.msRequestFullscreen) { // IE/Edge
        document.documentElement.msRequestFullscreen();
    }
}


function checkFullScreenRedfinger () {
    if (document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement) {
        return true;
    } else {
        return false;
    }
}


function exitFullScreenRedfinger () {
    if (document.exitFullscreen) {
        document.exitFullscreen();
    } else if (document.mozCancelFullScreen) { // Firefox
        document.mozCancelFullScreen();
    } else if (document.webkitExitFullscreen) { // Chrome, Safari and Opera
        document.webkitExitFullscreen();
    } else if (document.msExitFullscreen) { // IE/Edge
        document.msExitFullscreen();
    }
}