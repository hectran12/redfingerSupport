
document.getElementById('fullScreen').addEventListener('click', async () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
       
        chrome.tabs.sendMessage(tabs[0].id, { action: 'setFullScreen' }, (response) => {
            if (response.status === 'success') {
                setMessage('notification is-success', 'Đã set full screen thành công!');
            } else {
                setMessage('notification is-danger', 'Đã xảy ra lỗi, vui lòng bật redfinger web r ấn mở lại thì mới có thể bật fullscreen');
            }
        });
    });
});


document.getElementById('fullScreenAllSite').addEventListener('click', async () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'setFullScreenFullSite' }, (response) => {
            if (response.status === 'success') {
                setMessage('notification is-success', 'Đã set full screen all site thành công!');
            } else {
                setMessage('notification is-danger', 'Đã xảy ra lỗi, vui lòng bật redfinger web r ấn mở lại thì mới có thể bật fullscreen');
            }
        }
        );
    });
});


document.getElementById('exportLocalStorage').addEventListener('click', async () => {
    // get localStorage

    chrome.tabs.query({
        active: true, currentWindow: true
    }, (tabs) => {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'getLocalStorage' }, (response) => {
            if (response.status === 'success') {
                document.getElementById('localStorageInput').value = response.data;
                setMessage('notification is-success', 'Đã export localStorage thành công!');
            } else {
                setMessage('notification is-danger', 'Đã xảy ra lỗi');
            }
        });
    
    })

    
   
}); 

document.getElementById('copy').addEventListener('click', async () => {
    var copyText = document.getElementById('localStorageInput');
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    document.execCommand('copy');
    setMessage('notification is-success', 'Đã copy dữ liệu thành công!');
})


document.getElementById('login').addEventListener('click', async () => {


    try {
        var localStorageInput = document.getElementById('localStorageInput').value;
        if (localStorageInput.length == 0 || localStorageInput == '' || localStorageInput == null) {
            setMessage('notification is-danger', 'Vui lòng nhập dữ liệu');
            return;
        }

        var parseLocalStorage = checkVaildLocalStorage(localStorageInput); 

        if (parseLocalStorage == false) {
            var findData = findLocalStorage(localStorageInput);
            if (findData == false) {
                setMessage('notification is-danger', 'Dữ liệu không hợp lệ [1]');
                return;
            } else {
                parseLocalStorage = checkVaildLocalStorage(findData);
                if (parseLocalStorage == false) {
                    setMessage('notification is-danger', 'Dữ liệu không hợp lệ [2]');
                    return;
                }
            }
        }

        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            func: setLocalStorage,
            args: [parseLocalStorage]
            });
        }); 
        setMessage('notification is-success', 'Đã set localStorage thành công!');

    } catch {
        setMessage('notification is-danger', 'Đã xảy ra lỗi');
        return;
    }
    
});



function exportLocalStorage () { 
    // get localStorage
    var localStorageData = localStorage;
    var localStorageString = JSON.stringify(localStorageData);

}


function setLocalStorage (data) {
    // clear
    localStorage.clear();
    for (const [key, value] of Object.entries(data)) {
        localStorage.setItem(key, value);
    }

    // reload browser
    location.reload();

}

function findLocalStorage (str) {
    if (str.includes('|') == false) {
        return false;
    }

    var splitStr = str.split('|');
    let start = 0;
    let end = 0;
    for (var i = 0; i < splitStr.length; i++) {
        var data = splitStr[i];
        if(data.includes('{"')) {
            if(start == 0) start = i;
        }
        if(data.includes('"}')) {
            if (end == 0) end = i;
        }
    }

    if (start == 0 && end == 0) {
        return false;
    }

    var newStr = '';
    for (var i = start; i <= end; i++) {
        newStr += splitStr[i];
    }

    return newStr;
}


function checkVaildLocalStorage (str) {

    try {
        var newLocalStorage = '';
        var parse = null;
        if(str.includes('userFloatInfo')) {
            newLocalStorage = str.split(',"userFloatInfo"')[0]
            newLocalStorage += ',"session_id"' + str.split(',"session_id"')[1]
            parse = JSON.parse(newLocalStorage);
        } else {
            parse = JSON.parse(str);
        }
        return parse;
    } catch {
        return false;
    }
    
}

function setMessage(className, message) {
    const messageElement = document.getElementById('messageAlert');
    messageElement.className = className;
    messageElement.innerText = message;
}